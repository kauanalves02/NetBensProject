package sweet.acessory;
    import model.Conexao;
public class SweetAcessory {

    public static void main(String[] args) {
        Conexao c = new Conexao();
        c.conectar();
    }
    
}

