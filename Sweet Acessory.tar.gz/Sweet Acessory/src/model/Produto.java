
package model;


public class Produto {

    private int id; 
    private String materiais;
    private String valores; 
    
    public int getId() {
        return id;
    }

    
    public void setId(int id) {
        this.id = id;
    }

    
    public String getMateriais() {
        return materiais;
    }

    
    public void setMateriais(String materiais) {
        this.materiais = materiais;
    }

    
    public String getValores() {
        return valores;
    }

    
    public void setValores(String valores) {
        this.valores = valores;
    }
}
